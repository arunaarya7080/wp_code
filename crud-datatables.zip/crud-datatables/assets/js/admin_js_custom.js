jQuery(document).ready(function ($) {
    // Update button click handler
    $('.update-btn').on('click', function () {
        var id = $(this).data('id');
        var row = $(this).closest('tr');
        $('#update_id').val(id);
        $('#update_name').val(row.find('td:eq(1)').text());
        $('#update_email').val(row.find('td:eq(2)').text());
        $('#update_number').val(row.find('td:eq(3)').text());
        $('#update_designation').val(row.find('td:eq(4)').text());
        $('#update_pincode').val(row.find('td:eq(5)').text());
        $('#update_city').val(row.find('td:eq(6)').text());
        $('#update_address').val(row.find('td:eq(7)').text());
    });
    // Handle Delete button click
    $('.delete-btn').on('click', function () {
        var id = $(this).data('id');
        $('#delete_id').val(id);
    });
});

jQuery(document).ready(function ($) {
    new DataTable('#crudTable');
});

