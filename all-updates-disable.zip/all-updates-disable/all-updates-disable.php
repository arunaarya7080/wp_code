<?php
/**
 * Plugin Name: All Updates Disable 
 * Plugin URI: Arun Kumar
 * Description: Disables all WordPress core, theme, and plugin updates and notifications.
 * Version: 1.0
 * Author: Arun Kumar
 * Author URI: Arun Kumar
 **/

// Disable all WordPress Updates
add_filter('pre_site_transient_update_core', '__return_null');
add_filter('pre_site_transient_update_plugins', '__return_null');
add_filter('pre_site_transient_update_themes', '__return_null');

// Disable automatic background updates
add_filter('automatic_updater_disabled', '__return_true');

// Disable update notifications in the admin dashboard
add_action('admin_menu', function () {
    remove_action('load-update-core.php', 'wp_update_plugins');
    remove_action('load-update-core.php', 'wp_update_themes');
    remove_action('admin_notices', 'update_nag', 3);
});

// Disable core update emails
add_filter('auto_core_update_send_email', '__return_false');

// Disable plugin update emails
add_filter('auto_plugin_update_send_email', '__return_false');

// Disable theme update emails
add_filter('auto_theme_update_send_email', '__return_false');

// Hide dashboard update notifications for all users
add_action('admin_menu', function () {
    remove_action('admin_notices', 'update_nag', 3);
});

// Hide dashboard update notifications for non-admin users
add_action('admin_menu', function () {
    if (!current_user_can('update_core')) {
        remove_action('admin_notices', 'update_nag', 3);
    }
});

// Remove the 'Updates' menu item from the admin interface
add_action('admin_menu', function () {
    global $submenu;
    remove_submenu_page('index.php', 'update-core.php');
}, 102);

// Disable core, theme, and plugin updates
add_action('init', function () {
    remove_action('load-update-core.php', 'wp_update_core');
    remove_action('load-update-core.php', 'wp_update_themes');
    remove_action('load-update-core.php', 'wp_update_plugins');
}, 1);

// Code End Thank You By @Arun Kumar