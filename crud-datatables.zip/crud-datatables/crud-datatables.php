<?php

/**
 * Plugin Name: CRUD DataTables
 * Plugin URI: Arun Kumar
 * Description: Provides CRUD operations and displays data using Bootstrap 5 DataTables.
 * Version: 1.0
 * Author: Arun Kumar
 * Author URI: Arun Kumar
 **/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Create table on plugin activation
function crud_datatables_activate()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'crud_data';

    if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") != $table_name) {
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            email varchar(255) NOT NULL,
            number varchar(15) NOT NULL,
            designation varchar(100) NOT NULL,
            pincode varchar(10) NOT NULL,
            city varchar(100) NOT NULL,
            address text NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}
register_activation_hook(__FILE__, 'crud_datatables_activate');

// Delete table on plugin deactivation
function crud_datatables_deactivate()
{
    // global $wpdb;
    // $table_name = $wpdb->prefix . 'crud_data';
    // $sql = "DROP TABLE IF EXISTS $table_name;";
    // $wpdb->query($sql);
}
register_deactivation_hook(__FILE__, 'crud_datatables_deactivate');

// Delete table on plugin uninstall
function crud_datatables_uninstall()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'crud_data';
    $sql = "DROP TABLE IF EXISTS $table_name;";
    $wpdb->query($sql);
}
register_uninstall_hook(__FILE__, 'crud_datatables_uninstall');


// Enqueue scripts and styles for the admin area
function crud_datatables_enqueue_admin_scripts($hook)
{
    // Check if we're on the plugin's admin page
    if ($hook != 'toplevel_page_crud-datatables') {
        return;
    }

    // Enqueue Bootstrap CSS
    wp_enqueue_style('bootstrap5-css', 'https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css');

    // Enqueue DataTables CSS
    wp_enqueue_style('datatables-bt5-css', 'https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap5.min.css');

    // Enqueue custom admin CSS
    wp_enqueue_style('admin_style_custom-css', plugins_url('assets/css/admin_style_custom.css', __FILE__));

    // Enqueue jQuery (if not already included)
    // wp_enqueue_script('jquery');

    // Enqueue Bootstrap JS
    wp_enqueue_script('bootstrap5-js', 'https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js', array('jquery'), null, true);

    // Enqueue DataTables JS
    wp_enqueue_script('datatables-js', 'https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js', array('jquery'), null, true);
    wp_enqueue_script('datatables-bt5-js', 'https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap5.min.js', array('jquery'), null, true);

    // Enqueue custom admin JS
    wp_enqueue_script('admin_js_custom', plugins_url('assets/js/admin_js_custom.js', __FILE__), array('jquery'), null, true);
}
add_action('admin_enqueue_scripts', 'crud_datatables_enqueue_admin_scripts');


// Add menu page
function crud_datatables_menu()
{
    add_menu_page(
        'CRUD DataTables',     // Page title
        'CRUD DataTables',     // Menu title
        'manage_options',      // Capability
        'crud-datatables',     // Menu slug
        'crud_datatables_page', // Function to display the page content
        'dashicons-database',  // Icon URL
        6                      // Position
    );
}
add_action('admin_menu', 'crud_datatables_menu');

// Display plugin page
function crud_datatables_page()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'crud_data';

    // Handle form actions
    if (isset($_POST['action'])) {
        check_admin_referer('crud_datatables_nonce_action', 'crud_datatables_nonce');

        if ($_POST['action'] == 'add_data') {
            $wpdb->insert(
                $table_name,
                array(
                    'name'        => sanitize_text_field($_POST['name']),
                    'email'       => sanitize_email($_POST['email']),
                    'number'      => sanitize_text_field($_POST['number']),
                    'designation' => sanitize_text_field($_POST['designation']),
                    'pincode'     => sanitize_text_field($_POST['pincode']),
                    'city'        => sanitize_text_field($_POST['city']),
                    'address'     => sanitize_textarea_field($_POST['address']),
                )
            );
        } elseif ($_POST['action'] == 'update') {
            $wpdb->update(
                $table_name,
                array(
                    'name'        => sanitize_text_field($_POST['name']),
                    'email'       => sanitize_email($_POST['email']),
                    'number'      => sanitize_text_field($_POST['number']),
                    'designation' => sanitize_text_field($_POST['designation']),
                    'pincode'     => sanitize_text_field($_POST['pincode']),
                    'city'        => sanitize_text_field($_POST['city']),
                    'address'     => sanitize_textarea_field($_POST['address']),
                ),
                array('id' => intval($_POST['id']))
            );
        } elseif ($_POST['action'] == 'delete') {
            $wpdb->delete($table_name, array('id' => intval($_POST['id'])));
        }
    }

    $data = $wpdb->get_results("SELECT * FROM $table_name");
?>

    <div class="wrap">
        <h1 class="fs-2 fw-bold">CRUD DataTables</h1>

        <!-- Insert Modal -->
        <div class="modal fade" id="insertModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="insertModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="insertModalLabel">Insert Record</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="insertForm" method="post">
                            <?php wp_nonce_field('crud_datatables_nonce_action', 'crud_datatables_nonce'); ?>
                            <div class="mb-3">
                                <label for="insert_name" class="form-label">Name</label>
                                <input type="text" class="form-control" id="insert_name" name="name" required>
                            </div>
                            <div class="mb-3">
                                <label for="insert_email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="insert_email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="insert_number" class="form-label">Phone Number</label>
                                <input type="text" class="form-control" id="insert_number" name="number" required>
                            </div>
                            <div class="mb-3">
                                <label for="insert_designation" class="form-label">Designation</label>
                                <input type="text" class="form-control" id="insert_designation" name="designation" required>
                            </div>
                            <div class="mb-3">
                                <label for="insert_pincode" class="form-label">Pincode</label>
                                <input type="text" class="form-control" id="insert_pincode" name="pincode" required>
                            </div>
                            <div class="mb-3">
                                <label for="insert_city" class="form-label">City</label>
                                <input type="text" class="form-control" id="insert_city" name="city" required>
                            </div>
                            <div class="mb-3">
                                <label for="insert_address" class="form-label">Address</label>
                                <textarea class="form-control" id="insert_address" name="address" rows="3" required></textarea>
                            </div>
                            <input type="hidden" name="action" value="add_data">
                            <input type="submit" name="submit" id="submit" class="btn btn-primary" value="Insert Record">
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Update Modal -->
        <div class="modal fade" id="updateModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="updateModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="updateModalLabel">Update Record</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="updateForm" method="post">
                            <?php wp_nonce_field('crud_datatables_nonce_action', 'crud_datatables_nonce'); ?>
                            <div class="mb-3">
                                <label for="update_name" class="form-label">Name</label>
                                <input type="text" class="form-control" id="update_name" name="name" required>
                            </div>
                            <div class="mb-3">
                                <label for="update_email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="update_email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="update_number" class="form-label">Phone Number</label>
                                <input type="text" class="form-control" id="update_number" name="number" required>
                            </div>
                            <div class="mb-3">
                                <label for="update_designation" class="form-label">Designation</label>
                                <input type="text" class="form-control" id="update_designation" name="designation" required>
                            </div>
                            <div class="mb-3">
                                <label for="update_pincode" class="form-label">Pincode</label>
                                <input type="text" class="form-control" id="update_pincode" name="pincode" required>
                            </div>
                            <div class="mb-3">
                                <label for="update_city" class="form-label">City</label>
                                <input type="text" class="form-control" id="update_city" name="city" required>
                            </div>
                            <div class="mb-3">
                                <label for="update_address" class="form-label">Address</label>
                                <textarea class="form-control" id="update_address" name="address" rows="3" required></textarea>
                            </div>
                            <input type="hidden" id="update_id" name="id">
                            <input type="hidden" name="action" value="update">
                            <input type="submit" name="submit" id="submit" class="btn btn-warning" value="Update Record">
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Delete Modal -->
        <div class="modal fade" id="deleteModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLabel">Delete Record</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="deleteForm" method="post">
                            <?php wp_nonce_field('crud_datatables_nonce_action', 'crud_datatables_nonce'); ?>
                            <p>Are you sure you want to delete this record?</p>
                            <input type="hidden" id="delete_id" name="id">
                            <input type="hidden" name="action" value="delete">
                            <input type="submit" name="submit" id="submit" class="btn btn-danger" value="Delete Record">
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <button class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#insertModal">Add New Record</button>

        <table id="crudTable" class="table table-striped" style="width:100%">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone Number</th>
                    <th>Designation</th>
                    <th>Pincode</th>
                    <th>City</th>
                    <th>Address</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data as $row) : ?>
                    <tr>
                        <td><?php echo esc_html($row->id); ?></td>
                        <td><?php echo esc_html($row->name); ?></td>
                        <td><?php echo esc_html($row->email); ?></td>
                        <td><?php echo esc_html($row->number); ?></td>
                        <td><?php echo esc_html($row->designation); ?></td>
                        <td><?php echo esc_html($row->pincode); ?></td>
                        <td><?php echo esc_html($row->city); ?></td>
                        <td><?php echo esc_html($row->address); ?></td>
                        <td>
                            <button class="btn btn-warning btn-sm update-btn" data-id="<?php echo esc_attr($row->id); ?>" data-bs-toggle="modal" data-bs-target="#updateModal">Edit</button>
                            <button class="btn btn-danger btn-sm delete-btn" data-id="<?php echo esc_attr($row->id); ?>" data-bs-toggle="modal" data-bs-target="#deleteModal">Delete</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php
}
